package com.valenciaBank.valenciaBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValenciaBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValenciaBankApplication.class, args);
	}


}
