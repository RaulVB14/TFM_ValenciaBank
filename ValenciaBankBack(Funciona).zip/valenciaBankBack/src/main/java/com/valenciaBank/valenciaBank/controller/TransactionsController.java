package com.valenciaBank.valenciaBank.controller;

import com.valenciaBank.valenciaBank.model.Transaction;
import com.valenciaBank.valenciaBank.model.User;
import com.valenciaBank.valenciaBank.service.TransactionService;
import com.valenciaBank.valenciaBank.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/transactions")
@CrossOrigin
public class TransactionsController {



    @Autowired
    private TransactionService transactionsService;

    @Autowired
    private UserService userService;

    @PostMapping("/add")
    public String add(@RequestBody User user) {

        Transaction transaction = new Transaction();
        transaction.setUser(user);  // Asegúrate de que `someUser` no sea null
        transaction.setOriginAccount(transaction.getDestinationAccount());
        transactionsService.saveTransaction(transaction);
        return "Hemos hecho una transacción";
    }

    @PostMapping("/deposit/add")
    public String addDeposit(@RequestBody User user) {
        System.out.println(user);
        System.out.println(user.getDni());
        System.out.println(user.getTransactions());
        System.out.println(user.getPassword());
        System.out.println(user.getId());
        System.out.println(user.getUsername());
        System.out.println(user.getAccount());
        Transaction transaction = new Transaction();
        transaction.setUser(user);
        // Asegúrate de que `someUser` no sea null
        //FALLO
        user.setTransactions(user.getTransactions());
        transactionsService.saveTransaction(transaction);
        return "Hemos hecho un ingreso a la cuenta";
    }


}
